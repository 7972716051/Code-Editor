# Code Editor Project (Local Save Enabled)

## What this is
A local demo project: a web-based code editor using CodeMirror (frontend) and a simple Node.js/Express backend that can run JavaScript (node), Python (python3), and C++ (g++) code submitted by the user.
This version additionally supports saving/loading/deleting code snippets locally on the server in the `snippets/` folder.

## WARNING
This project executes user-submitted code on the server. **DO NOT** deploy this to a public server. This is intended for local development only.

## Requirements (to run locally)
- Node.js (v14+)
- Python 3 (for Python code execution)
- g++ (for compiling/running C++ code)

## Install & run
1. Unzip the project.
2. In the project folder, run:
   ```
   npm install
   npm start
   ```
3. Open `http://localhost:3000` in your browser.

## Snippets storage
- Snippets are saved as JSON files in the `snippets/` directory.
- Use the UI buttons to save the current code as a snippet, load a saved snippet, or delete a snippet.

## Notes & limitations
- Timeouts and buffers are set to small values to limit abuse.
- No sandboxing is implemented. For safe, production-ready execution, use proper sandboxing (Docker, gVisor, firejail) and resource limits.
