const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const { exec } = require('child_process');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(bodyParser.json({ limit: '5mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const SNIPPETS_DIR = path.join(__dirname, 'snippets');
if (!fs.existsSync(SNIPPETS_DIR)) fs.mkdirSync(SNIPPETS_DIR, { recursive: true });

// Save a snippet (name, language, code) -> saves as JSON file
app.post('/api/snippets/save', (req, res) => {
    const { name, language, code } = req.body;
    if (!name || !language || code === undefined) return res.status(400).json({ error: 'name, language and code required' });
    const safeName = name.replace(/[^a-z0-9_\-\. ]/gi, '_').trim();
    const id = uuidv4();
    const filename = `${Date.now()}_${safeName}_${id}.json`;
    const filepath = path.join(SNIPPETS_DIR, filename);
    const payload = { id, name: safeName, language, code, createdAt: new Date().toISOString() };
    fs.writeFile(filepath, JSON.stringify(payload, null, 2), (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true, file: filename, snippet: payload });
    });
});

// List snippets
app.get('/api/snippets/list', (req, res) => {
    fs.readdir(SNIPPETS_DIR, (err, files) => {
        if (err) return res.status(500).json({ error: err.message });
        const snippets = files.filter(f => f.endsWith('.json')).map(f => {
            try {
                const raw = fs.readFileSync(path.join(SNIPPETS_DIR, f), 'utf-8');
                const obj = JSON.parse(raw);
                return { file: f, name: obj.name, language: obj.language, createdAt: obj.createdAt };
            } catch (e) {
                return null;
            }
        }).filter(Boolean).sort((a,b) => new Date(b.createdAt) - new Date(a.createdAt));
        res.json({ success: true, snippets });
    });
});

// Load snippet by filename
app.get('/api/snippets/load', (req, res) => {
    const file = req.query.file;
    if (!file) return res.status(400).json({ error: 'file query parameter required' });
    const filepath = path.join(SNIPPETS_DIR, path.basename(file));
    if (!fs.existsSync(filepath)) return res.status(404).json({ error: 'snippet not found' });
    try {
        const raw = fs.readFileSync(filepath, 'utf-8');
        const obj = JSON.parse(raw);
        res.json({ success: true, snippet: obj });
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

// Delete snippet
app.post('/api/snippets/delete', (req, res) => {
    const { file } = req.body;
    if (!file) return res.status(400).json({ error: 'file required' });
    const filepath = path.join(SNIPPETS_DIR, path.basename(file));
    if (!fs.existsSync(filepath)) return res.status(404).json({ error: 'not found' });
    fs.unlink(filepath, (err) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json({ success: true });
    });
});

// Execute code endpoint (same as before)
app.post('/run', async (req, res) => {
    const { language, code } = req.body;
    if (!language || code === undefined) return res.status(400).json({ error: 'language and code required' });

    const id = uuidv4();
    const workdir = path.join(__dirname, 'tmp');
    if (!fs.existsSync(workdir)) fs.mkdirSync(workdir);
    const safeId = id.replace(/[^a-z0-9\-]/gi, '');
    try {
        if (language === 'javascript') {
            const file = path.join(workdir, safeId + '.js');
            fs.writeFileSync(file, code);
            exec(`node "${file}"`, { timeout: 5000, maxBuffer: 1024 * 1024 }, (err, stdout, stderr) => {
                if (err) {
                    return res.json({ success: false, stdout: stdout, stderr: (stderr || err.message) });
                }
                res.json({ success: true, stdout: stdout, stderr: stderr });
            });
        } else if (language === 'python') {
            const file = path.join(workdir, safeId + '.py');
            fs.writeFileSync(file, code);
            exec(`python3 "${file}"`, { timeout: 5000, maxBuffer: 1024 * 1024 }, (err, stdout, stderr) => {
                if (err) {
                    return res.json({ success: false, stdout: stdout, stderr: (stderr || err.message) });
                }
                res.json({ success: true, stdout: stdout, stderr: stderr });
            });
        } else if (language === 'cpp') {
            const cppFile = path.join(workdir, safeId + '.cpp');
            const exeFile = path.join(workdir, safeId + '.out');
            fs.writeFileSync(cppFile, code);
            // Compile
            exec(`g++ "${cppFile}" -O2 -std=c++17 -o "${exeFile}"`, { timeout: 10000, maxBuffer: 1024 * 1024 }, (compileErr, compileStdout, compileStderr) => {
                if (compileErr) {
                    return res.json({ success: false, stdout: compileStdout, stderr: compileStderr || compileErr.message });
                }
                // Run
                exec(`"${exeFile}"`, { timeout: 5000, maxBuffer: 1024 * 1024 }, (runErr, runStdout, runStderr) => {
                    if (runErr) {
                        return res.json({ success: false, stdout: runStdout, stderr: runStderr || runErr.message });
                    }
                    res.json({ success: true, stdout: runStdout, stderr: runStderr });
                });
            });
        } else {
            res.status(400).json({ error: 'unsupported language' });
        }
    } catch (e) {
        res.status(500).json({ error: e.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
