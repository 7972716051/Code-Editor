            // Frontend with save/load snippets functionality
            const textarea = document.getElementById('editor');
            const languageSelect = document.getElementById('language');
            const runBtn = document.getElementById('runBtn');
            const stdoutEl = document.getElementById('stdout');
            const stderrEl = document.getElementById('stderr');
            const downloadBtn = document.getElementById('downloadBtn');
            const saveBtn = document.getElementById('saveBtn');
            const snippetsList = document.getElementById('snippetsList');
            const deleteSnippetBtn = document.getElementById('deleteSnippetBtn');
            const darkMode = document.getElementById('darkMode');

            // Initialize CodeMirror (v5)
            const editor = CodeMirror.fromTextArea(textarea, {
              lineNumbers: true,
              mode: 'javascript',
              indentUnit: 2,
              smartIndent: true,
              matchBrackets: true,
              autofocus: true,
            });

            // Sample templates
            const templates = {
              javascript: `console.log("Hello from JavaScript");`,
              python: `print("Hello from Python")`,
              cpp: `#include <bits/stdc++.h>
using namespace std;
int main(){\n    cout<<"Hello from C++"<<"\n";\n    return 0;\n}`,
            };

            function setMode(lang){
              if(lang === 'javascript') editor.setOption('mode', 'javascript');
              if(lang === 'python') editor.setOption('mode', 'python');
              if(lang === 'cpp') editor.setOption('mode', 'text/x-c++src');
            }

            languageSelect.addEventListener('change', (e)=>{
              setMode(e.target.value);
              editor.setValue(templates[e.target.value] || '');
              refreshSnippetsList();
            });

            async function refreshSnippetsList(){
              try{
                const res = await fetch('/api/snippets/list');
                const data = await res.json();
                if(data.success){
                  // clear and populate
                  snippetsList.innerHTML = '<option value="">-- Load snippet --</option>';
                  data.snippets.forEach(s => {
                    const opt = document.createElement('option');
                    opt.value = s.file;
                    opt.textContent = `${s.name} (${s.language}) - ${new Date(s.createdAt).toLocaleString()}`;
                    opt.dataset.language = s.language;
                    snippetsList.appendChild(opt);
                  });
                }
              }catch(e){
                console.error(e);
              }
            }

            runBtn.addEventListener('click', async ()=>{
              const code = editor.getValue();
              const language = languageSelect.value;
              stdoutEl.textContent = 'Running...';
              stderrEl.textContent = '';
              try {
                const resp = await fetch('/run', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ language, code })
                });
                const data = await resp.json();
                if(data.success){
                  stdoutEl.textContent = data.stdout || '';
                  stderrEl.textContent = data.stderr || '';
                } else {
                  stdoutEl.textContent = data.stdout || '';
                  stderrEl.textContent = data.stderr || data.error || 'Execution failed';
                }
              } catch (err) {
                stdoutEl.textContent = '';
                stderrEl.textContent = err.message;
              }
            });

            downloadBtn.addEventListener('click', ()=>{
              const blob = new Blob([editor.getValue()], { type: 'text/plain' });
              const a = document.createElement('a');
              a.href = URL.createObjectURL(blob);
              const ext = languageSelect.value === 'python' ? 'py' : (languageSelect.value === 'cpp' ? 'cpp' : 'js');
              a.download = `code.${ext}`;
              a.click();
            });

            saveBtn.addEventListener('click', async ()=>{
              const name = prompt('Enter a name for this snippet (short):');
              if(!name) return;
              const payload = { name, language: languageSelect.value, code: editor.getValue() };
              try{
                const res = await fetch('/api/snippets/save', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(payload)
                });
                const data = await res.json();
                if(data.success){
                  alert('Snippet saved.');
                  refreshSnippetsList();
                } else {
                  alert('Save failed: ' + (data.error || 'unknown'));
                }
              }catch(e){
                alert('Save failed: ' + e.message);
              }
            });

            snippetsList.addEventListener('change', async (e)=>{
              const file = e.target.value;
              if(!file) return;
              try{
                const res = await fetch('/api/snippets/load?file=' + encodeURIComponent(file));
                const data = await res.json();
                if(data.success && data.snippet){
                  languageSelect.value = data.snippet.language;
                  setMode(data.snippet.language);
                  editor.setValue(data.snippet.code);
                } else {
                  alert('Load failed: ' + (data.error || 'unknown'));
                }
              }catch(e){
                alert('Load failed: ' + e.message);
              }
            });

            deleteSnippetBtn.addEventListener('click', async ()=>{
              const file = snippetsList.value;
              if(!file){ alert('Select a snippet first'); return; }
              if(!confirm('Delete selected snippet?')) return;
              try{
                const res = await fetch('/api/snippets/delete', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ file })
                });
                const data = await res.json();
                if(data.success){
                  alert('Deleted.');
                  refreshSnippetsList();
                } else {
                  alert('Delete failed: ' + (data.error || 'unknown'));
                }
              }catch(e){
                alert('Delete failed: ' + e.message);
              }
            });

            darkMode.addEventListener('change', (e)=>{
              if(e.target.checked) document.documentElement.setAttribute('data-theme', 'dark');
              else document.documentElement.removeAttribute('data-theme');
            });

            // initialize defaults
            languageSelect.value = 'javascript';
            setMode('javascript');
            editor.setValue(templates.javascript);
            refreshSnippetsList();
